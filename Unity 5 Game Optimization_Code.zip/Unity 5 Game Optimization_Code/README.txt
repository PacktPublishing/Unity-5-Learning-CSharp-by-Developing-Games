Detailed installation steps (software-wise)

1.	Software A:
a.	Go to https://unity3d.com/get-unity/download?ref=personal (Personal Edition download area for Unity 5.x � free download)
b.	Click �Download� to download the latest version
c.	Install in the default location
d.	Open the application
e.	Create a new project
f.	Double-click the *.unitypackage code files
g.	The Unity Window will open, requesting to import the files contained within the package into the current Project
h.	Click �Import�
i.	Note that files may need to be upgradedif running a Unity version greater than 5.0.1f
i.	Files will appear in the Unity project
