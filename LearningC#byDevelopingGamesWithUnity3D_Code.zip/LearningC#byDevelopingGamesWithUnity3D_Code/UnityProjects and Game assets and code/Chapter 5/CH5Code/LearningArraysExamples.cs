﻿using UnityEngine;
using System.Collections;

public class LearningArraysExamples : MonoBehaviour {



	string[] familyMembers = new string[]{"John", "Amanda", "Chris", "Amber"};


	string[] carsInTheGarage = new string[] {"VWPassat", "BMW"};


	int[] doorNumbersOnMyStreet = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12 };


	GameObject[] carsInTheScene = GameObject.FindGameObjectsWithTag("car");




}
