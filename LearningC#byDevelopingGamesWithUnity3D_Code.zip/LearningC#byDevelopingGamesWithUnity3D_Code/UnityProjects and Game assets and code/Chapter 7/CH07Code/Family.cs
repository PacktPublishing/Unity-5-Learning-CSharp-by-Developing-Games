﻿using UnityEngine;
using System.Collections;

public class Family : MonoBehaviour {


	public Person father;
	public Person mother;
	public Person son;


	void Start() {

//		father = new Person();
//		father.firstName = "Greg";
//		father.lastName = "Lukosek";
//		father.age = 29;
//		father.isMale = true;
//		father.isMarried = true;
//
//
//		mother = new Person();
//		mother.firstName = "Kate";
//		mother.lastName = "Lukosek";
//		mother.age = 28;
//		mother.isMale = false;
//		mother.isMarried = true;
//
//
//		son = new Person();
//		son.firstName = "Adam";
//		son.lastName = "Lukosek";
//		son.age = 3;
//		son.isMale = true;
//		son.isMarried = false;
//
//
//
//		Debug.Log(father.firstName + " and " + mother.firstName + 
//		          " have a beautiful son " + son.firstName);
//

	}
}



