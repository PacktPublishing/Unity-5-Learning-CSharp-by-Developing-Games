Chapter 1:  Code present
Chapter 2:  No code
Chapter 3:  No code
Chapter 4:  Code present
Chapter 5:  Code present
Chapter 6:  Code present
Chapter 7:  Code present
Chapter 8:  No code
Chapter 9:  Code present
Chapter 10: Code present
Chapter 11: Code present
Chapter 12: Code present
Chapter 13: Code present



You will definitely need a computer�PC, Mac, or any machine that supports Unity editor intallatio.
The complete Unity system requirements can be found at this link:
https://unity3d.com/unity/system-requirements